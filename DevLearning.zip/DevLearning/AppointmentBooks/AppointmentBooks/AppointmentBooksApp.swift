//
//  AppointmentBooksApp.swift
//  AppointmentBooks
//
//  Created by Makape Tema on 2024/02/05.
//

import SwiftUI

@main
struct AppointmentBooksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
