//
//  AppointmenBookingView.swift
//  AppointmentBooks
//
//  Created by Makape Tema on 2024/02/05.
//

import SwiftUI

struct AppointmentBookingView: View {
    var body: some View {
        Text("Appointment Booking View")
    }
}


//struct AppointmenBookingView_Previews: PreviewProvider {
//    static var previews: some View {
//        AppointmenBookingView()
//    }
//}
