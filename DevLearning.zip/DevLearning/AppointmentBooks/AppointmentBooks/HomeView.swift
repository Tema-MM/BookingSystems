//// Empty state or list of bookings
//
//import SwiftUI
//
//struct HomeView: View {
//    var body: some View {
//        VStack {
//            Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
//                .padding()
//            Spacer()
//            Text("No appointments")
//                .bold()
//            Spacer()
//            LargeButton(title: "Make an appointment",
//                        backgroundColor: Color.yellow) {
//                                   BookingFormView()
//                                }.padding(.horizontal)
//                .cornerRadius(20)
//        }
//    }
//}
//
//struct HomeView_Previews: PreviewProvider {
//    static var previews: some View {
//        HomeView()
//    }
//}

//import SwiftUI
//
//struct HomeView: View {
//    var body: some View {
//        NavigationView {
//            VStack {
//                HStack {
//                    Image(systemName: "person.circle")
//
//                }
//                .padding(.leading, 350)
//                Divider()
//
//                Spacer()
//                Text("No appointments")
//                    .bold()
//                Spacer()
//
//                NavigationLink(destination: BookingFormView()) {
//                    LargeButton(title: "Make an appointment",
//                                backgroundColor: Color.yellow, action: {})
//                        .padding(.horizontal)
//                        .cornerRadius(20)
//                }
//            }
//            .navigationBarTitle("Home")
//        }
//    }
//}
//
//struct HomeView_Previews: PreviewProvider {
//    static var previews: some View {
//        HomeView()
//    }
//}

import SwiftUI

struct HomeView: View {
    @State private var isBookingFormPresented = false
    
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Image(systemName: "person.circle")
                    Spacer()
                }
                .padding()

                Divider()
                
                Spacer()
                Text("No appointments")
                    .bold()
                Spacer()
                
                Button(action: {
                    self.isBookingFormPresented = true
                }) {
                    LargeButton(title: "Make an appointment",
                                backgroundColor: Color.yellow, action: {})
                        .padding(.horizontal)
                        .cornerRadius(20)
                }
                .popover(isPresented: $isBookingFormPresented, content: {
                    BookingFormView()
                })
            }
            .navigationBarTitle("Home")
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
