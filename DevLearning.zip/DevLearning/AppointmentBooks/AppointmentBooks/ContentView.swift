import SwiftUI
import MapKit
import CoreLocation

struct ContentView: View {
    @State private var centerCoordinate = CLLocationCoordinate2D(latitude: -26.1076, longitude: 28.0567) // Sandton coordinates
//    @State private var mapItems: [MKMapItem] = []
    @State var selectedPlace: MKPlacemark?
    
    var body: some View {
        NavigationView {
            TabView {
                HomeView()
                    .tabItem {
                        Image(systemName: "house")
                        Text("Home")
                        
                    }
                
//                BookingFormView()
//                    .tabItem {
//                        Image(systemName: "calendar")
//                        Text("Book Appointment")
//                        
//                    }
                
                MapView(centerCoordinate: $centerCoordinate, selectedPlace: $selectedPlace)
                                .edgesIgnoringSafeArea(.all)
//                                .frame(height: 300)
                
//                            List(mapItems, id: \.self) { item in
//                                Text(item.name ?? "Unknown")
//                            }
                    .tabItem {
                        Image(systemName: "map")
                        Text("Map")
                    }
            }
            .navigationTitle("Appointment App")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


//struct ContentView: View {
//    @State private var centerCoordinate = CLLocationCoordinate2D(latitude: -26.1076, longitude: 28.0567) // Sandton coordinates
//    @State private var mapItems: [MKMapItem] = []
//
//    var body: some View {
//        VStack {
//            MapView(centerCoordinate: $centerCoordinate, mapItems: $mapItems)
//                .edgesIgnoringSafeArea(.all)
//                .frame(height: 300)
//
//            List(mapItems, id: \.self) { item in
//                Text(item.name ?? "Unknown")
//            }
//        }
//    }
//}
