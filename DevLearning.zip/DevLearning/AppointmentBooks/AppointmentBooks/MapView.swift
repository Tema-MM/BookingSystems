//import SwiftUI
//import MapKit
//
//struct MapView: UIViewRepresentable {
//    @Binding var centerCoordinate: CLLocationCoordinate2D
//
//    let locationManager = CLLocationManager()
//
//    func makeUIView(context: Context) -> MKMapView {
//        let mapView = MKMapView()
//        mapView.delegate = context.coordinator
//        mapView.showsUserLocation = true
//        return mapView
//    }
//
//    func updateUIView(_ mapView: MKMapView, context: Context) {
//        // Center the map on the provided coordinate
//        let region = MKCoordinateRegion(center: centerCoordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
//        mapView.setRegion(region, animated: true)
//    }
//
//    func makeCoordinator() -> Coordinator {
//        Coordinator(self)
//    }
//
//    class Coordinator: NSObject, MKMapViewDelegate, CLLocationManagerDelegate {
//        var parent: MapView
//
//        init(_ parent: MapView) {
//            self.parent = parent
//            super.init()
//
//            parent.locationManager.delegate = self
//            parent.locationManager.desiredAccuracy = kCLLocationAccuracyBest
//            parent.locationManager.requestWhenInUseAuthorization()
//            parent.locationManager.startUpdatingLocation()
//        }
//
//        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//            if let location = locations.last {
//                parent.centerCoordinate = location.coordinate
//                parent.locationManager.stopUpdatingLocation()
//            }
//        }
//
//        func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
//            print("Failed to find user's location: \(error.localizedDescription)")
//        }
//    }
//}
//
//struct ShowMapView: View {
//    @State private var centerCoordinate = CLLocationCoordinate2D(latitude: -26.1076, longitude: 28.0567) // Sandton coordinates
//
//    var body: some View {
//        MapView(centerCoordinate: $centerCoordinate)
//            .edgesIgnoringSafeArea(.all)
//    }
//}
//
//struct ShowMapView_Previews: PreviewProvider {
//    static var previews: some View {
//        ShowMapView()
//    }
//}
//


import SwiftUI
import MapKit

struct MapView: UIViewRepresentable {
    @Binding var centerCoordinate: CLLocationCoordinate2D
    @Binding var selectedPlace: MKPlacemark?
    
    let locationManager = CLLocationManager()
    @State private var query: String = ""
    
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = true
        return mapView
    }
    
    func updateUIView(_ mapView: MKMapView, context: Context) {
        // Center the map on the provided coordinate
        let region = MKCoordinateRegion(center: centerCoordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        mapView.setRegion(region, animated: true)
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, MKMapViewDelegate, CLLocationManagerDelegate {
        var parent: MapView
        
        init(_ parent: MapView) {
            self.parent = parent
            super.init()
            
            parent.locationManager.delegate = self
            parent.locationManager.desiredAccuracy = kCLLocationAccuracyBest
            parent.locationManager.requestWhenInUseAuthorization()
            parent.locationManager.startUpdatingLocation()
        }
        
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
            if let location = locations.last {
                parent.centerCoordinate = location.coordinate
                parent.locationManager.stopUpdatingLocation()
            }
        }
        
        func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
            print("Failed to find user's location: \(error.localizedDescription)")
        }
        
        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            guard annotation is MKPointAnnotation else { return nil }

            let identifier = "Placemark"
            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)

            if annotationView == nil {
                annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                annotationView?.canShowCallout = true
            } else {
                annotationView?.annotation = annotation
            }

            return annotationView
        }
    }
}

struct SearchBar: View {
    @Binding var query: String
    var onSearch: () -> Void

    var body: some View {
        HStack {
            TextField("Search for places", text: $query, onCommit: {
                onSearch()
            })
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding(.horizontal)

            Button(action: {
                onSearch()
            }) {
                Text("Search")
            }
            .padding(.trailing)
        }
    }
}

struct ShowMapView: View {
    @State private var centerCoordinate = CLLocationCoordinate2D(latitude: -26.1076, longitude: 28.0567) // Sandton coordinates
    @State private var selectedPlace: MKPlacemark?
    @State private var query: String = ""
    
    var body: some View {
        VStack {
            SearchBar(query: $query) {
                // Handle the search functionality here
                // You can use a geocoder to convert the query to a placemark
                // and update the map accordingly
            }
            .padding()

            MapView(centerCoordinate: $centerCoordinate, selectedPlace: $selectedPlace)
                .edgesIgnoringSafeArea(.all)
        }
    }
}

struct ShowMapView_Previews: PreviewProvider {
    static var previews: some View {
        ShowMapView()
    }
}
