//import SwiftUI
//import MapKit
//
//struct SearchBar: View {
//    @Binding var landmarks: [MKPlacemark]
//    @Binding var region: MKCoordinateRegion
//    @State private var searchText: String = ""
//    
//    var body: some View {
//        VStack {
//            TextField("Search", text: $searchText, onEditingChanged: { _ in }, onCommit: {
//                // Perform search for landmarks
//            })
//            .padding()
//            .background(Color(.systemGray5))
//            .cornerRadius(10)
//            
//            List(landmarks, id: \.self) { landmark in
//                Text("\(landmark.name ?? "")")
//            }
//        }
//        .padding()
//    }
//}
