//
//  MapBusinessApp.swift
//  MapBusiness
//
//  Created by Federico on 26/02/2022.
//

import SwiftUI

@main
struct MapBusinessApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
